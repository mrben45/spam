clear
figlet SPAM |lolcat
echo '
   GUNAKAN SCRIPTS INI DENGAN BIJAK
   TERIMA KASIH BY PLANKSTON
'
echo "1).sms"
echo "2).cal"
echo "3).out"
echo ""
read -p "no : " k;

case $k in
1)
cd .sms
python bot.py
cd ..
sh .l
sh bot.sh
exit
;;

2)
cd .cal
python bot.py
cd ..
sh .l
sh bot.sh
exit
;;

3)
echo ""
echo " program dihentikan!"
exit
;;

setup)
mv .setup setup
sh setup
figlet DONE! |lolcat
sleep 5
sh .l
sh bot.sh
exit
;;
*)
echo ""
echo "   nomor yg anda masukan salah!"
sleep 3
sh bot.sh
exit
esac
exit
done
